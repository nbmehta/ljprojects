/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author kishanmadhu
 */
@Entity
@Table(name = "NEWCAR")
@XmlRootElement
public class Newcar extends CommonCarEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Size(max = 255)
    @Column(name = "ASSISTANCE_PACKAGE")
    private String assistancePackage;
    
    @Column(name = "EXTENDING_WARRANTY")
    private Integer extendingWarranty;
    
    @Column(name = "WARRANTY")
    private Integer warranty;

    public Newcar() {
    }

    public String getAssistancePackage() {
        return assistancePackage;
    }

    public void setAssistancePackage(String assistancePackage) {
        this.assistancePackage = assistancePackage;
    }

    public Integer getExtendingWarranty() {
        return extendingWarranty;
    }

    public void setExtendingWarranty(Integer extendingWarranty) {
        this.extendingWarranty = extendingWarranty;
    }

    public Integer getWarranty() {
        return warranty;
    }

    public void setWarranty(Integer warranty) {
        this.warranty = warranty;
    }
    
}
