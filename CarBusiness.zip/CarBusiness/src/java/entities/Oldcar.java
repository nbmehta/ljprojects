/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author kishanmadhu
 */
@Entity
@Table(name = "OLDCAR")
@XmlRootElement
public class Oldcar extends CommonCarEntity implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Size(max = 255)
    @Column(name = "CAR_HISTORY")
    private String carHistory;
    
    @Column(name = "ODOMETER")
    private Integer odometer;
    
    @Column(name = "REGO_EXPIRY")
    private Integer regoExpiry;
    @Size(max = 255)
    @Column(name = "REGO_NO")
    private String regoNo;
    
    @Size(max = 255)
    @Column(name = "SERVICE_HISTORY")
    private String serviceHistory;
    
    @Size(max = 255)
    @Column(name = "VEHICLE_INFORMATION_NO")
    private String vehicleInformationNo;

    public Oldcar() {
    }

    

    public String getCarHistory() {
        return carHistory;
    }

    public void setCarHistory(String carHistory) {
        this.carHistory = carHistory;
    }

    

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Integer getRegoExpiry() {
        return regoExpiry;
    }

    public void setRegoExpiry(Integer regoExpiry) {
        this.regoExpiry = regoExpiry;
    }

    public String getRegoNo() {
        return regoNo;
    }

    public void setRegoNo(String regoNo) {
        this.regoNo = regoNo;
    }

    

    public String getServiceHistory() {
        return serviceHistory;
    }

    public void setServiceHistory(String serviceHistory) {
        this.serviceHistory = serviceHistory;
    }

    

    public String getVehicleInformationNo() {
        return vehicleInformationNo;
    }

    public void setVehicleInformationNo(String vehicleInformationNo) {
        this.vehicleInformationNo = vehicleInformationNo;
    }

    
}
