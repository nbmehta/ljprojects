/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import entities.Oldcar;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author kishanmadhu
 */
@Stateless
public class OldcarFacade extends AbstractFacade<Oldcar> {

    @PersistenceContext(unitName = "CarBusinessPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public OldcarFacade() {
        super(Oldcar.class);
    }
    
    public List<Oldcar> findWithRefNo(String refernceNo) {
        return em.createQuery(
                "SELECT c FROM Oldcar c WHERE c.refernceNo LIKE :refernceNo")
                .setParameter("refernceNo", refernceNo)
                .setMaxResults(10)
                .getResultList();
    }
    
    public Integer updateQuantity(Integer carId, Integer quantityNo, char operation ) {
        Integer rowsUpdated = em.createQuery("UPDATE Oldcar c SET c.quantity = c.quantity "+operation +" :quantityNo WHERE c.id = :carId")
                .setParameter("quantityNo", quantityNo)
                .setParameter("carId", carId)
                .executeUpdate();

        return rowsUpdated;
    }

    public Oldcar findWithModel(String model) {

        List<Oldcar> list = em.createQuery("SELECT c FROM Oldcar c WHERE c.model LIKE :model")
                .setParameter("model", model)
                .setMaxResults(1)
                .getResultList();

        if (list != null && !list.isEmpty()) {
            return list.get(0);
        }
        return null;
    }
}
