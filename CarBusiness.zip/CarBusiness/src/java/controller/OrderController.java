/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.CustomerFacade;
import Model.NewcarFacade;
import Model.OldcarFacade;
import Model.OrdersFacade;
import entities.Newcar;
import entities.Oldcar;
import entities.Orders;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author kishanmadhu
 */
@Named(value = "orderController")
@SessionScoped
public class OrderController implements Serializable {

    @EJB
    private OrdersFacade ordersFacade;
    private Orders orders = new Orders();
    private List<Orders> orderListFound;
    
    
    @EJB
    private CustomerFacade customerFacade;
    
    @EJB
    private OldcarFacade oldCarFacade;
    
    @EJB
    private NewcarFacade newCarFacade;

    private Map<String, Integer> customerMap;
    private Map<String, String> carModelAndPriceList;
    private Integer orderCounter;
    private String message;
    private String carWithPrice;
    private Integer customerMapId;
    private Integer orderNo;

    public OrderController() {

    }

    public List<Orders> findAll() {
        List<Orders> _orders = ordersFacade.findAll();
        orderCounter = _orders.size();
        return _orders;
    }
    
     public String findWitOrderNo() {
         if(orderNo!=null){
             orderListFound  = ordersFacade.findWithId(orderNo);
             if(orderListFound==null || orderListFound.isEmpty()){
                 setMessage("Order not found with order no "+orderNo);
             }
             orderCounter = orderListFound.size();
         }
        return "orderFound.xhtml";
    }

    public String insert() {

        if (carWithPrice != null) {
            
            orders.setCar(carWithPrice.substring(0, carWithPrice.lastIndexOf("-")));
            orders.setUnitPrice(Integer.parseInt(carWithPrice.substring(carWithPrice.lastIndexOf("-") + 1, carWithPrice.length() - 1).trim()));
            
            Newcar newCar = null;
            if ((newCar = newCarFacade.findWithModel(orders.getCar().trim())) != null) {

                if (newCar.getQuantity() - orders.getQuantity() < 0) {
                    setMessage("Stock is less then " + orders.getQuantity());
                    return "listorder.xhtml";
                }
                newCarFacade.updateQuantity(newCar.getId(), orders.getQuantity(), '-');
            }
            
            Oldcar oldCar = null;
            if ((oldCar = oldCarFacade.findWithModel(orders.getCar().trim())) != null) {
                if (newCar.getQuantity() - orders.getQuantity() < 0) {
                    setMessage("Stock is less then " + orders.getQuantity());
                    return "listorder.xhtml";
                }
                oldCarFacade.updateQuantity(oldCar.getId(), orders.getQuantity(), '-');
            }
        }

        if (customerMapId != null) {
            orders.setCustomer(customerFacade.findWithId(customerMapId));
        }

        orders.setCreateDate(new Timestamp(new Date().getTime()));
        ordersFacade.create(orders);
        
        setMessage("Created order of " + orders.getCustomer().getName());
        return "listorder.xhtml";
    }
    
    public String delete(Orders orders) {

        Newcar newCar = null;
            if ((newCar = newCarFacade.findWithModel(orders.getCar().trim())) != null) {
                newCarFacade.updateQuantity(newCar.getId(), orders.getQuantity(), '+');
            }
            Oldcar oldCar = null;
            if ((oldCar = oldCarFacade.findWithModel(orders.getCar().trim())) != null) {
                oldCarFacade.updateQuantity(oldCar.getId(), orders.getQuantity(), '+');
            }

        ordersFacade.remove(orders);
        setMessage("Deleted order for " + orders.getCustomer().getName());
        return "listorder.xhtml";
    }
    
    public Orders getOrders() {
        return orders;
    }

    public void setOrders(Orders orders) {
        this.orders = orders;
    }

    public List<Orders> getOrderListFound() {
        return orderListFound;
    }

    public void setOrderListFound(List<Orders> orderListFound) {
        this.orderListFound = orderListFound;
    }

    public Integer getOrderCounter() {
        return orderCounter;
    }

    public void setOrderCounter(Integer orderCounter) {
        this.orderCounter = orderCounter;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Map<String, Integer> getCustomerMap() {
        this.customerMap = new HashMap<>();
        customerFacade.findAll().forEach((c) -> {
            customerMap.put(c.getName(), c.getId());
        });
        return customerMap;
    }

    public void setCustomerMap(Map<String, Integer> customerMap) {
        this.customerMap = customerMap;
    }

    public Map<String, String> getCarModelAndPriceList() {

        List<Newcar> new_CarList = newCarFacade.findAll();
        List<Oldcar> old_CarList = oldCarFacade.findAll();

        this.carModelAndPriceList = new HashMap<>();
        old_CarList.forEach((car) -> {
            carModelAndPriceList.put(car.getModel() + " - " + car.getPrice(), car.getModel() + " - " + car.getPrice());
        });
        new_CarList.forEach((car) -> {
            carModelAndPriceList.put(car.getModel() + " - " + car.getPrice(), car.getModel() + " - " + car.getPrice());
        });
        return carModelAndPriceList;
    }

    public void setCarModelAndPriceList(Map<String, String> carModelAndPriceList) {
        this.carModelAndPriceList = carModelAndPriceList;
    }

    public String getCarWithPrice() {
        return carWithPrice;
    }

    public void setCarWithPrice(String carWithPrice) {
        this.carWithPrice = carWithPrice;
    }

    public Integer getCustomerMapId() {
        return customerMapId;
    }

    public void setCustomerMapId(Integer customerMapId) {
        this.customerMapId = customerMapId;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }
}

