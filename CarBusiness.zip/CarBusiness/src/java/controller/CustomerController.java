/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.CustomerFacade;
import entities.Customer;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;

/**
 *
 * @author kishanmadhu
 */
@Named(value = "customerController")
@SessionScoped
public class CustomerController implements Serializable {

    @EJB
    private CustomerFacade customerFacade;
    
    private Customer customer = new Customer();

    private Integer customerCount = 0;
    private Integer customerId;
    private String customerName;
    private List<Customer> customerList;
    private String message;
    
    /**
     * Creates a new instance of CustomerController
     */
    public CustomerController() {
    }
    
    public String insert() {

        FacesContext ctx = FacesContext.getCurrentInstance();
        
        if ((customer.getName()==null ||"".equals(customer.getName())) ||  (customer.getAddress()==null || "".equals(customer.getAddress()))|| (customer.getPhone()==null || "".equals(customer.getPhone()))|| (customer.getEmail()==null ||"".equals(customer.getEmail())) )
        {
            ctx.addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN,"All Fields values are reruired",""));
        }
        else
        {
            customerFacade.create(customer);
            FacesContext.getCurrentInstance().addMessage(null,new FacesMessage(FacesMessage.SEVERITY_INFO,"Suceesfully created the customer:" +customer.getName(),""));
            
        }
        return "listcustomer.xhtml";
    }

    public String findWithName(String name) {
        setCustomerList(customerFacade.findWithName(name));
        return "foundCustomer.xhtml";
    }

    public String showDetails(Customer customer) {
        setCustomer(customer);
        return "viewCustomerDetails.xhtml";
    }

    public List<Customer> findAll() {
        List list = customerFacade.findAll();
        setCustomerCount(list.size());
        return list;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Integer getCustomerCount() {
        return customerCount;
    }

    public void setCustomerCount(Integer customerCount) {
        this.customerCount = customerCount;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public List<Customer> getCustomerList() {
        return customerList;
    }

    public void setCustomerList(List<Customer> customerList) {
        this.customerList = customerList;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    } 
}
