/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.OldcarFacade;
import entities.Oldcar;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;

/**
 *
 * @author kishanmadhu
 */
@Named(value = "usedCarController")
@SessionScoped
public class UsedCarController implements Serializable {

    @EJB
    private OldcarFacade carFacade;
    private Oldcar car = new Oldcar();
    private List<Oldcar> carListFound ;
    private Integer carCounter;
    private String refernceNo;
    private String message;
    
    /**
     * Creates a new instance of UsedCarController
     */
    public UsedCarController() {
    }
    
    public List<Oldcar> findAll() {
        setMessage("");
        List<Oldcar> cars = carFacade.findAll();
        carCounter = cars.size();
        return cars;
    }
    
    public String findWithRefNo(String refernceNumber) {
        setCarListFound(carFacade.findWithRefNo(refernceNumber));
        return "foundusedCars.xhtml";
    }

    public String insert() {
        carFacade.create(car);
        setMessage("Created the used car: " + car.getMake() + " " + car.getModel());
        this.car = new Oldcar();
        return "listusedcar.xhtml";
    }

    public Oldcar getCar() {
        return car;
    }

    public void setCar(Oldcar car) {
        this.car = car;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getCarCounter() {
        return carCounter;
    }

    public void setCarCounter(Integer carCounter) {
        this.carCounter = carCounter;
    }

    public String getRefernceNo() {
        return refernceNo;
    }

    public void setRefernceNo(String refernceNo) {
        this.refernceNo = refernceNo;
    }

    public List<Oldcar> getCarListFound() {
        return carListFound;
    }

    public void setCarListFound(List<Oldcar> carListFound) {
        this.carListFound = carListFound;
    }
}
