/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.NewCar;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author kishanmadhu
 */
@Stateless
public class NewCarEJB extends AbstractEJB<NewCar> {

    @PersistenceContext(unitName = "CarPlatformPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public NewCarEJB() {
        super(NewCar.class);
    }
    
    public NewCar searchWithModel(String model) {

        List<NewCar> list = em.createQuery("SELECT c FROM NewCar c WHERE c.model LIKE :model")
                .setParameter("model", model)
                .setMaxResults(1)
                .getResultList();

        if (list != null && !list.isEmpty()) {
            return list.get(0);
        }
        return null;
    }
    
    public Integer updateQty(Integer carId, Integer quantity, char operation) {
        Integer rowsUpdated = em.createQuery("UPDATE NewCar c SET c.quantity = c.quantity "+operation +" :quantity WHERE c.id = :carId")
                .setParameter("quantity", quantity)
                .setParameter("carId", carId)
                .executeUpdate();
        return rowsUpdated;
    }
    
    public List<NewCar> searchWithReference(String refernceNo) {
        return em.createQuery(
                "SELECT c FROM NewCar c WHERE c.refernceNo LIKE :refernceNo")
                .setParameter("refernceNo", refernceNo)
                .setMaxResults(10)
                .getResultList();
    }
    
    

    
    
}
