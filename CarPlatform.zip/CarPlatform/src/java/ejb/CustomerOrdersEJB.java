/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb;

import entity.CustomerOrders;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author kishanmadhu
 */
@Stateless
public class CustomerOrdersEJB extends AbstractEJB<CustomerOrders> {

    @PersistenceContext(unitName = "CarPlatformPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public CustomerOrdersEJB() {
        super(CustomerOrders.class);
    }
    
    public  List<CustomerOrders> searchById(Integer id) {

        List<CustomerOrders> list = em.createQuery("SELECT o FROM CustomerOrders o WHERE o.id = :id")
                .setParameter("id", id)
                .setMaxResults(1)
                .getResultList();

        return list;
    }
}
