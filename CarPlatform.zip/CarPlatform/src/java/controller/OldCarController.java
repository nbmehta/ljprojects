/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.OldCarEJB;
import entity.OldCar;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author kishanmadhu
 */
@Named(value = "oldCarController")
@SessionScoped
public class OldCarController implements Serializable {

    
    @EJB
    private OldCarEJB oldCarEJB;
    private OldCar car = new OldCar();
    private List<OldCar> carList ;
    private Integer totalCars;
    private String refernceNumner;
    private String message;
    
    /**
     * Creates a new instance of OldCarController
     */
    public OldCarController() {
    }
    
    public List<OldCar> findAll() {
        setMessage("");
        List<OldCar> cars = oldCarEJB.findAll();
        totalCars = cars.size();
        return cars;
    }
    
    public String searchWithReference(String refernceNumber) {
        setCarList(oldCarEJB.searchWithReference(refernceNumber));
        return "foundusedCars.xhtml";
    }

    public String createNewCar() {
        oldCarEJB.create(car);
        this.car = new OldCar();
        setMessage("Created the brand used car: " + car.getMake() + " - " + car.getModel());
        return "listusedcar.xhtml";
    }
    
    public OldCar getCar() {
        return car;
    }

    public void setCar(OldCar car) {
        this.car = car;
    }

    public List<OldCar> getCarList() {
        return carList;
    }

    public void setCarList(List<OldCar> carList) {
        this.carList = carList;
    }

    public Integer getTotalCars() {
        return totalCars;
    }

    public void setTotalCars(Integer totalCars) {
        this.totalCars = totalCars;
    }

    public String getRefernceNumner() {
        return refernceNumner;
    }

    public void setRefernceNumner(String refernceNumner) {
        this.refernceNumner = refernceNumner;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
}
