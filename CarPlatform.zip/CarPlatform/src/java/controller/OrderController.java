/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.CustomerEJB;
import ejb.CustomerOrdersEJB;
import ejb.NewCarEJB;
import ejb.OldCarEJB;
import entity.CustomerOrders;
import entity.NewCar;
import entity.OldCar;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;

/**
 *
 * @author kishanmadhu
 */
@Named(value = "orderController")
@SessionScoped
public class OrderController implements Serializable {

    @EJB
    private CustomerOrdersEJB customerOrdersEJB;
    @EJB
    private CustomerEJB customerEJB;
    @EJB
    private OldCarEJB oldCarEJB;
    @EJB
    private NewCarEJB newCarEJB;
    
    private CustomerOrders orders = new CustomerOrders();
    private List<CustomerOrders> foundCustomerOrders;
    private Map<String, Integer> customersMap;
    private Map<String, String> carModelAndPriceList;
    private Integer orderCounter;
    private String message;
    private String carWithPrice;
    private Integer customerMapId;
    private Integer orderNo;
    
    /**
     * Creates a new instance of OrderController
     */
    public OrderController() {
    }

    public List<CustomerOrders> findAll() {
        List<CustomerOrders> _orders = customerOrdersEJB.findAll();
        orderCounter = _orders.size();
        return _orders;
    }
    
     public String findWitOrderNo() {
         if(orderNo!=null){
             foundCustomerOrders  = customerOrdersEJB.searchById(orderNo);
             if(foundCustomerOrders==null || foundCustomerOrders.isEmpty()){
                 setMessage("Order not found for order no "+orderNo);
             }
             orderCounter = foundCustomerOrders.size();
         }
        return "orderFound.xhtml";
    }

    public String insert() {

        if (carWithPrice != null) {
            
            orders.setCar(carWithPrice.substring(0, carWithPrice.lastIndexOf("-")));
            orders.setUnitPrice(Integer.parseInt(carWithPrice.substring(carWithPrice.lastIndexOf("-") + 1, carWithPrice.length() - 1).trim()));
            
            NewCar newCar = null;
            if ((newCar = newCarEJB.searchWithModel(orders.getCar().trim())) != null) {

                if (newCar.getQuantity() - orders.getQuantity() < 0) {
                    setMessage("Stock is less then " + orders.getQuantity());
                    return "listorder.xhtml";
                }
                newCarEJB.updateQty(newCar.getId(), orders.getQuantity(), '-');
            }
            
            OldCar oldCar = null;
            if ((oldCar = oldCarEJB.searchWithModel(orders.getCar().trim())) != null) {
                if (newCar.getQuantity() - orders.getQuantity() < 0) {
                    setMessage("Stock is less then " + orders.getQuantity());
                    return "listorder.xhtml";
                }
                oldCarEJB.updateQty(oldCar.getId(), orders.getQuantity(), '-');
            }
        }

        if (customerMapId != null) {
            orders.setCustomer(customerEJB.searchWithId(customerMapId));
        }

        orders.setCreateDate(new Timestamp(new Date().getTime()));
        customerOrdersEJB.create(orders);
        
        setMessage("Created order of " + orders.getCustomer().getName());
        return "listorder.xhtml";
    }
    
    public String delete(CustomerOrders orders) {

        NewCar newCar = null;
            if ((newCar = newCarEJB.searchWithModel(orders.getCar().trim())) != null) {
                newCarEJB.updateQty(newCar.getId(), orders.getQuantity(), '+');
            }
            OldCar oldCar = null;
            if ((oldCar = oldCarEJB.searchWithModel(orders.getCar().trim())) != null) {
                oldCarEJB.updateQty(oldCar.getId(), orders.getQuantity(), '+');
            }

        customerOrdersEJB.remove(orders);
        setMessage("Deleted order for " + orders.getCustomer().getName());
        return "listorder.xhtml";
    }

    public CustomerOrders getOrders() {
        return orders;
    }

    public void setOrders(CustomerOrders orders) {
        this.orders = orders;
    }

    public List<CustomerOrders> getFoundCustomerOrders() {
        return foundCustomerOrders;
    }

    public void setFoundCustomerOrders(List<CustomerOrders> foundCustomerOrders) {
        this.foundCustomerOrders = foundCustomerOrders;
    }

    public Map<String, Integer> getCustomersMap() {
        this.customersMap = new HashMap<>();
        customerEJB.findAll().forEach((_customer) -> {
            customersMap.put(_customer.getName(), _customer.getId());
        });
        return customersMap;
    }

    public void setCustomersMap(Map<String, Integer> customersMap) {
        this.customersMap = customersMap;
    }

    public Map<String, String> getCarModelAndPriceList() {
        List<NewCar> new_CarList = newCarEJB.findAll();
        List<OldCar> old_CarList = oldCarEJB.findAll();

        this.carModelAndPriceList = new HashMap<>();
        old_CarList.forEach((car) -> {
            carModelAndPriceList.put(car.getModel() + " - " + car.getPrice(), car.getModel() + " - " + car.getPrice());
        });
        new_CarList.forEach((car) -> {
            carModelAndPriceList.put(car.getModel() + " - " + car.getPrice(), car.getModel() + " - " + car.getPrice());
        });
        return carModelAndPriceList;
    }

    public void setCarModelAndPriceList(Map<String, String> carModelAndPriceList) {
        this.carModelAndPriceList = carModelAndPriceList;
    }

    public Integer getOrderCounter() {
        return orderCounter;
    }

    public void setOrderCounter(Integer orderCounter) {
        this.orderCounter = orderCounter;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCarWithPrice() {
        return carWithPrice;
    }

    public void setCarWithPrice(String carWithPrice) {
        this.carWithPrice = carWithPrice;
    }

    public Integer getCustomerMapId() {
        return customerMapId;
    }

    public void setCustomerMapId(Integer customerMapId) {
        this.customerMapId = customerMapId;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    } 
    
}
