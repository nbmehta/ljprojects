/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import ejb.NewCarEJB;
import entity.NewCar;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author kishanmadhu
 */
@Named(value = "newCarController")
@SessionScoped
public class NewCarController implements Serializable {

    @EJB
    private NewCarEJB newCarEJB;
    private NewCar car = new NewCar();
    private List<NewCar> carList ;
    private Integer totalCars;
    private String refernceNumner;
    private String message;
    
    /**
     * Creates a new instance of NewCarController
     */
    public NewCarController() {
    }
    
    public List<NewCar> findAll() {
        setMessage("");
        List<NewCar> cars = newCarEJB.findAll();
        totalCars = cars.size();
        return cars;
    }
    
    public String searchWithReference(String refernceNumber) {
        setCarList(newCarEJB.searchWithReference(refernceNumber));
        return "foundnewCars.xhtml";
    }

    public String createNewCar() {
        newCarEJB.create(car);
        this.car = new NewCar();
        setMessage("Created the brand new car: " + car.getMake() + " - " + car.getModel());
        return "listnewcar.xhtml";
    }

    public NewCar getCar() {
        return car;
    }

    public void setCar(NewCar car) {
        this.car = car;
    }

    public List<NewCar> getCarList() {
        return carList;
    }

    public void setCarList(List<NewCar> carList) {
        this.carList = carList;
    }

    public Integer getTotalCars() {
        return totalCars;
    }

    public void setTotalCars(Integer totalCars) {
        this.totalCars = totalCars;
    }

    public String getRefernceNumner() {
        return refernceNumner;
    }

    public void setRefernceNumner(String refernceNumner) {
        this.refernceNumner = refernceNumner;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
