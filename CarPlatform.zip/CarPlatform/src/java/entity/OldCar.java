/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author kishanmadhu
 */
@Entity
@Table(name = "OLD_CAR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "OldCar.findAll", query = "SELECT o FROM OldCar o")
    , @NamedQuery(name = "OldCar.findById", query = "SELECT o FROM OldCar o WHERE o.id = :id")
    , @NamedQuery(name = "OldCar.findByBodyColour", query = "SELECT o FROM OldCar o WHERE o.bodyColour = :bodyColour")
    , @NamedQuery(name = "OldCar.findByCarHistory", query = "SELECT o FROM OldCar o WHERE o.carHistory = :carHistory")
    , @NamedQuery(name = "OldCar.findByDoors", query = "SELECT o FROM OldCar o WHERE o.doors = :doors")
    , @NamedQuery(name = "OldCar.findByDriveType", query = "SELECT o FROM OldCar o WHERE o.driveType = :driveType")
    , @NamedQuery(name = "OldCar.findByEngine", query = "SELECT o FROM OldCar o WHERE o.engine = :engine")
    , @NamedQuery(name = "OldCar.findByFuelType", query = "SELECT o FROM OldCar o WHERE o.fuelType = :fuelType")
    , @NamedQuery(name = "OldCar.findByMake", query = "SELECT o FROM OldCar o WHERE o.make = :make")
    , @NamedQuery(name = "OldCar.findByModel", query = "SELECT o FROM OldCar o WHERE o.model = :model")
    , @NamedQuery(name = "OldCar.findByOdometer", query = "SELECT o FROM OldCar o WHERE o.odometer = :odometer")
    , @NamedQuery(name = "OldCar.findByPrice", query = "SELECT o FROM OldCar o WHERE o.price = :price")
    , @NamedQuery(name = "OldCar.findByQuantity", query = "SELECT o FROM OldCar o WHERE o.quantity = :quantity")
    , @NamedQuery(name = "OldCar.findByRefernceNo", query = "SELECT o FROM OldCar o WHERE o.refernceNo = :refernceNo")
    , @NamedQuery(name = "OldCar.findByRegoExpiry", query = "SELECT o FROM OldCar o WHERE o.regoExpiry = :regoExpiry")
    , @NamedQuery(name = "OldCar.findByRegoNo", query = "SELECT o FROM OldCar o WHERE o.regoNo = :regoNo")
    , @NamedQuery(name = "OldCar.findBySeats", query = "SELECT o FROM OldCar o WHERE o.seats = :seats")
    , @NamedQuery(name = "OldCar.findByServiceHistory", query = "SELECT o FROM OldCar o WHERE o.serviceHistory = :serviceHistory")
    , @NamedQuery(name = "OldCar.findByTransmission", query = "SELECT o FROM OldCar o WHERE o.transmission = :transmission")
    , @NamedQuery(name = "OldCar.findByVehicleInformationNo", query = "SELECT o FROM OldCar o WHERE o.vehicleInformationNo = :vehicleInformationNo")})
public class OldCar implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Size(max = 255)
    @Column(name = "BODY_COLOUR")
    private String bodyColour;
    @Size(max = 255)
    @Column(name = "CAR_HISTORY")
    private String carHistory;
    @Column(name = "DOORS")
    private Integer doors;
    @Size(max = 255)
    @Column(name = "DRIVE_TYPE")
    private String driveType;
    @Size(max = 255)
    @Column(name = "ENGINE")
    private String engine;
    @Size(max = 255)
    @Column(name = "FUEL_TYPE")
    private String fuelType;
    @Size(max = 255)
    @Column(name = "MAKE")
    private String make;
    @Size(max = 255)
    @Column(name = "MODEL")
    private String model;
    @Column(name = "ODOMETER")
    private Integer odometer;
    @Column(name = "PRICE")
    private Integer price;
    @Column(name = "QUANTITY")
    private Integer quantity;
    @Size(max = 255)
    @Column(name = "REFERNCE_NO")
    private String refernceNo;
    @Column(name = "REGO_EXPIRY")
    private Integer regoExpiry;
    @Size(max = 255)
    @Column(name = "REGO_NO")
    private String regoNo;
    @Column(name = "SEATS")
    private Integer seats;
    @Size(max = 255)
    @Column(name = "SERVICE_HISTORY")
    private String serviceHistory;
    @Size(max = 255)
    @Column(name = "TRANSMISSION")
    private String transmission;
    @Size(max = 255)
    @Column(name = "VEHICLE_INFORMATION_NO")
    private String vehicleInformationNo;

    public OldCar() {
    }

    public OldCar(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBodyColour() {
        return bodyColour;
    }

    public void setBodyColour(String bodyColour) {
        this.bodyColour = bodyColour;
    }

    public String getCarHistory() {
        return carHistory;
    }

    public void setCarHistory(String carHistory) {
        this.carHistory = carHistory;
    }

    public Integer getDoors() {
        return doors;
    }

    public void setDoors(Integer doors) {
        this.doors = doors;
    }

    public String getDriveType() {
        return driveType;
    }

    public void setDriveType(String driveType) {
        this.driveType = driveType;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getOdometer() {
        return odometer;
    }

    public void setOdometer(Integer odometer) {
        this.odometer = odometer;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getRefernceNo() {
        return refernceNo;
    }

    public void setRefernceNo(String refernceNo) {
        this.refernceNo = refernceNo;
    }

    public Integer getRegoExpiry() {
        return regoExpiry;
    }

    public void setRegoExpiry(Integer regoExpiry) {
        this.regoExpiry = regoExpiry;
    }

    public String getRegoNo() {
        return regoNo;
    }

    public void setRegoNo(String regoNo) {
        this.regoNo = regoNo;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public String getServiceHistory() {
        return serviceHistory;
    }

    public void setServiceHistory(String serviceHistory) {
        this.serviceHistory = serviceHistory;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public String getVehicleInformationNo() {
        return vehicleInformationNo;
    }

    public void setVehicleInformationNo(String vehicleInformationNo) {
        this.vehicleInformationNo = vehicleInformationNo;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OldCar)) {
            return false;
        }
        OldCar other = (OldCar) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.OldCar[ id=" + id + " ]";
    }
    
}
