/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

CREATE TABLE Customer_Orders (ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), car VARCHAR(255), create_date TIMESTAMP, quantity INTEGER, unit_price INTEGER, CUSTOMER_ID INTEGER, PRIMARY KEY (id));
CREATE TABLE OLD_CAR (ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), body_colour VARCHAR(255), car_history VARCHAR(255), doors INTEGER, drive_type VARCHAR(255), engine VARCHAR(255), fuel_type VARCHAR(255), make VARCHAR(255), model VARCHAR(255), odometer INTEGER, price INTEGER, quantity INTEGER, refernce_no VARCHAR(255), rego_expiry INTEGER, rego_no VARCHAR(255), seats INTEGER, service_history VARCHAR(255), transmission VARCHAR(255), vehicle_information_no VARCHAR(255), PRIMARY KEY (id));
CREATE TABLE CUSTOMER (ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), ADDRESS VARCHAR(255), EMAIL VARCHAR(255), NAME VARCHAR(255), PHONE VARCHAR(255), PRIMARY KEY (ID));
CREATE TABLE NEW_CAR (ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1), assistance_package VARCHAR(255), body_colour VARCHAR(255), model VARCHAR(255), price INTEGER, quantity INTEGER, refernce_no VARCHAR(255), seats INTEGER, transmission VARCHAR(255), warranty INTEGER, doors INTEGER, drive_type VARCHAR(255), engine VARCHAR(255), extending_warranty INTEGER, fuel_type VARCHAR(255), make VARCHAR(255), PRIMARY KEY (id));
ALTER TABLE Customer_Orders ADD CONSTRAINT ORDER_CUSTOMER_ID FOREIGN KEY (CUSTOMER_ID) REFERENCES CUSTOMER (ID)
