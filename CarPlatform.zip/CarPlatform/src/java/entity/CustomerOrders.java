/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author kishanmadhu
 */
@Entity
@Table(name = "CUSTOMER_ORDERS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "CustomerOrders.findAll", query = "SELECT c FROM CustomerOrders c")
    , @NamedQuery(name = "CustomerOrders.findById", query = "SELECT c FROM CustomerOrders c WHERE c.id = :id")
    , @NamedQuery(name = "CustomerOrders.findByCar", query = "SELECT c FROM CustomerOrders c WHERE c.car = :car")
    , @NamedQuery(name = "CustomerOrders.findByCreateDate", query = "SELECT c FROM CustomerOrders c WHERE c.createDate = :createDate")
    , @NamedQuery(name = "CustomerOrders.findByQuantity", query = "SELECT c FROM CustomerOrders c WHERE c.quantity = :quantity")
    , @NamedQuery(name = "CustomerOrders.findByUnitPrice", query = "SELECT c FROM CustomerOrders c WHERE c.unitPrice = :unitPrice")})
public class CustomerOrders implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Size(max = 255)
    @Column(name = "CAR")
    private String car;
    @Column(name = "CREATE_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createDate;
    @Column(name = "QUANTITY")
    private Integer quantity;
    @Column(name = "UNIT_PRICE")
    private Integer unitPrice;
    @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID")
    @ManyToOne
    private Customer customer;

    public CustomerOrders() {
    }

    public CustomerOrders(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCar() {
        return car;
    }

    public void setCar(String car) {
        this.car = car;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Integer getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(Integer unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customerId) {
        this.customer = customerId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CustomerOrders)) {
            return false;
        }
        CustomerOrders other = (CustomerOrders) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.CustomerOrders[ id=" + id + " ]";
    }
    
}
