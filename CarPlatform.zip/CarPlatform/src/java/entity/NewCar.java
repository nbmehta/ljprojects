/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author kishanmadhu
 */
@Entity
@Table(name = "NEW_CAR")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "NewCar.findAll", query = "SELECT n FROM NewCar n")
    , @NamedQuery(name = "NewCar.findById", query = "SELECT n FROM NewCar n WHERE n.id = :id")
    , @NamedQuery(name = "NewCar.findByAssistancePackage", query = "SELECT n FROM NewCar n WHERE n.assistancePackage = :assistancePackage")
    , @NamedQuery(name = "NewCar.findByBodyColour", query = "SELECT n FROM NewCar n WHERE n.bodyColour = :bodyColour")
    , @NamedQuery(name = "NewCar.findByModel", query = "SELECT n FROM NewCar n WHERE n.model = :model")
    , @NamedQuery(name = "NewCar.findByPrice", query = "SELECT n FROM NewCar n WHERE n.price = :price")
    , @NamedQuery(name = "NewCar.findByQuantity", query = "SELECT n FROM NewCar n WHERE n.quantity = :quantity")
    , @NamedQuery(name = "NewCar.findByRefernceNo", query = "SELECT n FROM NewCar n WHERE n.refernceNo = :refernceNo")
    , @NamedQuery(name = "NewCar.findBySeats", query = "SELECT n FROM NewCar n WHERE n.seats = :seats")
    , @NamedQuery(name = "NewCar.findByTransmission", query = "SELECT n FROM NewCar n WHERE n.transmission = :transmission")
    , @NamedQuery(name = "NewCar.findByWarranty", query = "SELECT n FROM NewCar n WHERE n.warranty = :warranty")
    , @NamedQuery(name = "NewCar.findByDoors", query = "SELECT n FROM NewCar n WHERE n.doors = :doors")
    , @NamedQuery(name = "NewCar.findByDriveType", query = "SELECT n FROM NewCar n WHERE n.driveType = :driveType")
    , @NamedQuery(name = "NewCar.findByEngine", query = "SELECT n FROM NewCar n WHERE n.engine = :engine")
    , @NamedQuery(name = "NewCar.findByExtendingWarranty", query = "SELECT n FROM NewCar n WHERE n.extendingWarranty = :extendingWarranty")
    , @NamedQuery(name = "NewCar.findByFuelType", query = "SELECT n FROM NewCar n WHERE n.fuelType = :fuelType")
    , @NamedQuery(name = "NewCar.findByMake", query = "SELECT n FROM NewCar n WHERE n.make = :make")})
public class NewCar implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Size(max = 255)
    @Column(name = "ASSISTANCE_PACKAGE")
    private String assistancePackage;
    @Size(max = 255)
    @Column(name = "BODY_COLOUR")
    private String bodyColour;
    @Size(max = 255)
    @Column(name = "MODEL")
    private String model;
    @Column(name = "PRICE")
    private Integer price;
    @Column(name = "QUANTITY")
    private Integer quantity;
    @Size(max = 255)
    @Column(name = "REFERNCE_NO")
    private String refernceNo;
    @Column(name = "SEATS")
    private Integer seats;
    @Size(max = 255)
    @Column(name = "TRANSMISSION")
    private String transmission;
    @Column(name = "WARRANTY")
    private Integer warranty;
    @Column(name = "DOORS")
    private Integer doors;
    @Size(max = 255)
    @Column(name = "DRIVE_TYPE")
    private String driveType;
    @Size(max = 255)
    @Column(name = "ENGINE")
    private String engine;
    @Column(name = "EXTENDING_WARRANTY")
    private Integer extendingWarranty;
    @Size(max = 255)
    @Column(name = "FUEL_TYPE")
    private String fuelType;
    @Size(max = 255)
    @Column(name = "MAKE")
    private String make;

    public NewCar() {
    }

    public NewCar(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAssistancePackage() {
        return assistancePackage;
    }

    public void setAssistancePackage(String assistancePackage) {
        this.assistancePackage = assistancePackage;
    }

    public String getBodyColour() {
        return bodyColour;
    }

    public void setBodyColour(String bodyColour) {
        this.bodyColour = bodyColour;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public String getRefernceNo() {
        return refernceNo;
    }

    public void setRefernceNo(String refernceNo) {
        this.refernceNo = refernceNo;
    }

    public Integer getSeats() {
        return seats;
    }

    public void setSeats(Integer seats) {
        this.seats = seats;
    }

    public String getTransmission() {
        return transmission;
    }

    public void setTransmission(String transmission) {
        this.transmission = transmission;
    }

    public Integer getWarranty() {
        return warranty;
    }

    public void setWarranty(Integer warranty) {
        this.warranty = warranty;
    }

    public Integer getDoors() {
        return doors;
    }

    public void setDoors(Integer doors) {
        this.doors = doors;
    }

    public String getDriveType() {
        return driveType;
    }

    public void setDriveType(String driveType) {
        this.driveType = driveType;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public Integer getExtendingWarranty() {
        return extendingWarranty;
    }

    public void setExtendingWarranty(Integer extendingWarranty) {
        this.extendingWarranty = extendingWarranty;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NewCar)) {
            return false;
        }
        NewCar other = (NewCar) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.NewCar[ id=" + id + " ]";
    }
    
}
